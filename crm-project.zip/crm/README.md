# Enterprise CRM System

A full-stack CRM for managing leads, customers, and sales pipelines.

**Tech Stack:** React.js, Node.js (Express), MongoDB (Mongoose), REST APIs, JWT Auth

## Features

1. **Lead Tracking & Deal Stages** — Kanban-style pipeline (New → Contacted → Qualified →
   Proposal Sent → Negotiation → Won/Lost), deal value, probability, priority, and owner.
2. **Sales Performance Dashboards** — Deals-by-stage bar chart, pipeline value pie chart,
   monthly won-revenue trend line, and a sales rep leaderboard (built with Recharts +
   MongoDB aggregation pipelines).
3. **Email & Activity Logs** — Log emails, calls, meetings, notes, and tasks against leads
   and customers; stage changes are auto-logged.
4. **Role-Based Access Control (RBAC)** — Four roles (`admin`, `sales_manager`,
   `sales_rep`, `viewer`) enforced both in API middleware and the UI. Sales reps only see
   their own leads; managers/admins see everything; only admins manage user roles.

## Project Structure

```
crm/
├── backend/                 Express REST API
│   ├── config/               DB connection + seed script
│   ├── controllers/          Route handlers / business logic
│   ├── middleware/           JWT auth, RBAC, error handling
│   ├── models/                Mongoose schemas (User, Customer, Lead, Activity)
│   ├── routes/                 Express routers
│   └── server.js              App entry point
└── frontend/                React app (Create React App)
    └── src/
        ├── components/        Navbar, ProtectedRoute
        ├── context/             AuthContext (JWT + role helpers)
        ├── pages/                Login, Register, Dashboard, Leads, Customers, Activities, Users
        └── services/            Axios API client
```

## Setup

### 1. Backend

```bash
cd backend
cp .env.example .env       # edit MONGO_URI / JWT_SECRET as needed
npm install
npm run seed                # creates sample admin/manager/rep users + sample data
npm run dev                  # starts API on http://localhost:5000
```

Seed accounts created by `npm run seed`:

| Role          | Email             | Password   |
|---------------|-------------------|------------|
| admin         | admin@crm.com     | admin123   |
| sales_manager | manager@crm.com   | manager123 |
| sales_rep     | rep@crm.com       | rep12345   |

### 2. Frontend

```bash
cd frontend
cp .env.example .env       # points to http://localhost:5000/api by default
npm install
npm start                    # starts React app on http://localhost:3000
```

### 3. MongoDB

Run MongoDB locally (`mongod`) or point `MONGO_URI` in `backend/.env` to a hosted
instance (e.g. MongoDB Atlas).

## API Overview

| Method | Endpoint                     | Access                  | Description                  |
|--------|-------------------------------|--------------------------|-------------------------------|
| POST   | `/api/auth/register`          | Public                   | Self-register as sales_rep   |
| POST   | `/api/auth/login`             | Public                   | Login, returns JWT           |
| GET    | `/api/auth/me`                | Authenticated            | Current user profile         |
| GET/POST | `/api/leads`                 | Authenticated            | List/create leads (deals)    |
| GET/PUT/DELETE | `/api/leads/:id`         | Authenticated (delete: admin/manager) | Manage a single lead |
| GET    | `/api/leads/stages/list`      | Authenticated            | List of pipeline stages      |
| GET/POST | `/api/customers`             | Authenticated            | List/create customers        |
| GET/PUT/DELETE | `/api/customers/:id`     | Authenticated (delete: admin/manager) | Manage a customer    |
| GET/POST | `/api/activities`            | Authenticated            | List/create activity log entries |
| GET    | `/api/dashboard/summary`      | Authenticated            | Aggregated pipeline/revenue stats |
| GET    | `/api/dashboard/leaderboard`  | Authenticated            | Reps ranked by won revenue   |
| GET    | `/api/users`                  | admin, sales_manager      | List all users               |
| PUT    | `/api/users/:id/role`         | admin                     | Change a user's role/status  |

## Role Permissions Summary

| Action                          | admin | sales_manager | sales_rep | viewer |
|----------------------------------|:---:|:---:|:---:|:---:|
| View own leads/customers          | ✅ | ✅ | ✅ | ✅ |
| View all leads/customers          | ✅ | ✅ | ❌ (own only) | ✅ |
| Create/update leads & customers   | ✅ | ✅ | ✅ | ❌ |
| Delete leads & customers          | ✅ | ✅ | ❌ | ❌ |
| View dashboards                   | ✅ | ✅ | ✅ (own data) | ✅ |
| Manage users / roles              | ✅ | view-only | ❌ | ❌ |

## Notes for Submission

- This is a working full-stack prototype intended to demonstrate architecture and core
  functionality end-to-end; for production use you'd add input validation libraries
  (e.g. Joi/Zod), rate limiting, refresh tokens, pagination, and automated tests.
- `npm run seed` is idempotent — it wipes and recreates collections, so re-run it anytime
  to reset demo data.
