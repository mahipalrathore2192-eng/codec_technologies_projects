import React, { useEffect, useState } from 'react';
import api from '../services/api';

const emptyForm = { type: 'Note', subject: '', description: '' };

const Activities = () => {
  const [activities, setActivities] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(true);

  const loadData = () => {
    api.get('/activities').then((res) => setActivities(res.data)).finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    await api.post('/activities', form);
    setForm(emptyForm);
    setShowForm(false);
    loadData();
  };

  if (loading) return <div className="center-screen">Loading activity log...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Email &amp; Activity Log</h1>
        <button onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ Log Activity'}
        </button>
      </div>

      {showForm && (
        <form className="inline-form" onSubmit={handleCreate}>
          <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
            <option>Email</option>
            <option>Call</option>
            <option>Meeting</option>
            <option>Note</option>
            <option>Task</option>
          </select>
          <input
            placeholder="Subject"
            value={form.subject}
            onChange={(e) => setForm({ ...form, subject: e.target.value })}
            required
          />
          <input
            placeholder="Description"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
          />
          <button type="submit">Save</button>
        </form>
      )}

      <div className="activity-list">
        {activities.map((a) => (
          <div className="activity-item" key={a._id}>
            <span className={`activity-badge badge-${a.type.toLowerCase()}`}>{a.type}</span>
            <div className="activity-body">
              <div className="activity-subject">{a.subject}</div>
              {a.description && <div className="activity-desc">{a.description}</div>}
              <div className="activity-meta">
                {a.user?.name} &middot; {new Date(a.createdAt).toLocaleString()}
                {a.lead?.title ? ` · Lead: ${a.lead.title}` : ''}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Activities;
