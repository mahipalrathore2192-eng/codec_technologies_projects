import React, { useEffect, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
  CartesianGrid,
} from 'recharts';
import api from '../services/api';

const COLORS = ['#6366f1', '#22c55e', '#f59e0b', '#ef4444', '#06b6d4', '#a855f7', '#84cc16'];

const Dashboard = () => {
  const [summary, setSummary] = useState(null);
  const [leaderboard, setLeaderboard] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get('/dashboard/summary'), api.get('/dashboard/leaderboard')])
      .then(([s, l]) => {
        setSummary(s.data);
        setLeaderboard(l.data);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="center-screen">Loading dashboard...</div>;
  if (!summary) return <div className="center-screen">No data available</div>;

  const { byStage, totals, monthlyWonRevenue } = summary;

  const monthlyData = monthlyWonRevenue.map((m) => ({
    label: `${m._id.month}/${m._id.year}`,
    value: m.value,
  }));

  return (
    <div className="page">
      <h1>Sales Performance Dashboard</h1>

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">Total Leads</div>
          <div className="stat-value">{totals.totalLeads}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Pipeline Value</div>
          <div className="stat-value">${totals.totalValue.toLocaleString()}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Won Revenue</div>
          <div className="stat-value">${totals.wonValue.toLocaleString()}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Won / Lost</div>
          <div className="stat-value">
            {totals.wonCount} / {totals.lostCount}
          </div>
        </div>
      </div>

      <div className="chart-grid">
        <div className="chart-card">
          <h3>Deals by Stage</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={byStage}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="_id" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#6366f1" name="Deal Count" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Pipeline Value Distribution</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie
                data={byStage}
                dataKey="value"
                nameKey="_id"
                cx="50%"
                cy="50%"
                outerRadius={90}
                label
              >
                {byStage.map((entry, index) => (
                  <Cell key={entry._id} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Monthly Won Revenue</h3>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="label" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#22c55e" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Sales Leaderboard</h3>
          <table className="simple-table">
            <thead>
              <tr>
                <th>Rep</th>
                <th>Deals Won</th>
                <th>Revenue</th>
              </tr>
            </thead>
            <tbody>
              {leaderboard.map((row) => (
                <tr key={row.email}>
                  <td>{row.name}</td>
                  <td>{row.wonCount}</td>
                  <td>${row.wonValue.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
