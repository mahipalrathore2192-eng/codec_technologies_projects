import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const ROLES = ['admin', 'sales_manager', 'sales_rep', 'viewer'];

const Users = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const { hasRole } = useAuth();

  const loadData = () => {
    api.get('/users').then((res) => setUsers(res.data)).finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
  }, []);

  const updateRole = async (id, role) => {
    await api.put(`/users/${id}/role`, { role });
    loadData();
  };

  const toggleActive = async (id, isActive) => {
    await api.put(`/users/${id}/role`, { isActive: !isActive });
    loadData();
  };

  if (loading) return <div className="center-screen">Loading users...</div>;

  return (
    <div className="page">
      <h1>User Management (Role-Based Access Control)</h1>
      <table className="simple-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u._id}>
              <td>{u.name}</td>
              <td>{u.email}</td>
              <td>
                {hasRole('admin') ? (
                  <select value={u.role} onChange={(e) => updateRole(u._id, e.target.value)}>
                    {ROLES.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                ) : (
                  u.role
                )}
              </td>
              <td>{u.isActive ? 'Active' : 'Disabled'}</td>
              <td>
                {hasRole('admin') && (
                  <button onClick={() => toggleActive(u._id, u.isActive)}>
                    {u.isActive ? 'Disable' : 'Enable'}
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Users;
