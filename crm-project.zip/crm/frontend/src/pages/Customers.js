import React, { useEffect, useState } from 'react';
import api from '../services/api';

const emptyForm = { name: '', company: '', email: '', phone: '', industry: '' };

const Customers = () => {
  const [customers, setCustomers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(true);

  const loadData = () => {
    api.get('/customers').then((res) => setCustomers(res.data)).finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    await api.post('/customers', form);
    setForm(emptyForm);
    setShowForm(false);
    loadData();
  };

  if (loading) return <div className="center-screen">Loading customers...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Customers</h1>
        <button onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New Customer'}
        </button>
      </div>

      {showForm && (
        <form className="inline-form" onSubmit={handleCreate}>
          <input
            placeholder="Customer name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            required
          />
          <input
            placeholder="Company"
            value={form.company}
            onChange={(e) => setForm({ ...form, company: e.target.value })}
          />
          <input
            placeholder="Email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
          <input
            placeholder="Industry"
            value={form.industry}
            onChange={(e) => setForm({ ...form, industry: e.target.value })}
          />
          <button type="submit">Save Customer</button>
        </form>
      )}

      <table className="simple-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Company</th>
            <th>Email</th>
            <th>Industry</th>
            <th>Owner</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((c) => (
            <tr key={c._id}>
              <td>{c.name}</td>
              <td>{c.company}</td>
              <td>{c.email}</td>
              <td>{c.industry}</td>
              <td>{c.owner?.name}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Customers;
