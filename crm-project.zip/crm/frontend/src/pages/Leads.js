import React, { useEffect, useState } from 'react';
import api from '../services/api';

const STAGE_COLORS = {
  New: '#94a3b8',
  Contacted: '#60a5fa',
  Qualified: '#818cf8',
  'Proposal Sent': '#f59e0b',
  Negotiation: '#fb923c',
  Won: '#22c55e',
  Lost: '#ef4444',
};

const emptyForm = {
  title: '',
  contactName: '',
  contactEmail: '',
  source: 'Website',
  stage: 'New',
  value: 0,
  priority: 'Medium',
};

const Leads = () => {
  const [leads, setLeads] = useState([]);
  const [stages, setStages] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(true);

  const loadData = () => {
    Promise.all([api.get('/leads'), api.get('/leads/stages/list')])
      .then(([l, s]) => {
        setLeads(l.data);
        setStages(s.data);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    await api.post('/leads', { ...form, value: Number(form.value) });
    setForm(emptyForm);
    setShowForm(false);
    loadData();
  };

  const moveStage = async (id, newStage) => {
    await api.put(`/leads/${id}`, { stage: newStage });
    loadData();
  };

  if (loading) return <div className="center-screen">Loading pipeline...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Leads &amp; Deal Pipeline</h1>
        <button onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New Lead'}
        </button>
      </div>

      {showForm && (
        <form className="inline-form" onSubmit={handleCreate}>
          <input
            placeholder="Deal title"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            required
          />
          <input
            placeholder="Contact name"
            value={form.contactName}
            onChange={(e) => setForm({ ...form, contactName: e.target.value })}
          />
          <input
            placeholder="Contact email"
            value={form.contactEmail}
            onChange={(e) => setForm({ ...form, contactEmail: e.target.value })}
          />
          <input
            type="number"
            placeholder="Deal value ($)"
            value={form.value}
            onChange={(e) => setForm({ ...form, value: e.target.value })}
          />
          <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
            <option>Low</option>
            <option>Medium</option>
            <option>High</option>
          </select>
          <button type="submit">Save Lead</button>
        </form>
      )}

      <div className="kanban">
        {stages.map((stage) => (
          <div className="kanban-column" key={stage}>
            <div
              className="kanban-column-header"
              style={{ borderColor: STAGE_COLORS[stage] }}
            >
              {stage} ({leads.filter((l) => l.stage === stage).length})
            </div>
            {leads
              .filter((l) => l.stage === stage)
              .map((lead) => (
                <div className="kanban-card" key={lead._id}>
                  <div className="kanban-card-title">{lead.title}</div>
                  <div className="kanban-card-meta">
                    {lead.contactName} &middot; ${lead.value.toLocaleString()}
                  </div>
                  <div className="kanban-card-meta">Owner: {lead.owner?.name}</div>
                  <select
                    value={lead.stage}
                    onChange={(e) => moveStage(lead._id, e.target.value)}
                  >
                    {stages.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Leads;
