import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout, hasRole } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand">Enterprise CRM</div>
      <div className="navbar-links">
        <Link to="/dashboard">Dashboard</Link>
        <Link to="/leads">Leads &amp; Deals</Link>
        <Link to="/customers">Customers</Link>
        <Link to="/activities">Activity Log</Link>
        {hasRole('admin', 'sales_manager') && <Link to="/users">Users</Link>}
      </div>
      <div className="navbar-user">
        <span>
          {user.name} <small>({user.role})</small>
        </span>
        <button onClick={handleLogout}>Logout</button>
      </div>
    </nav>
  );
};

export default Navbar;
