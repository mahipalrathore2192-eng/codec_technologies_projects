const Lead = require('../models/Lead');
const mongoose = require('mongoose');

// GET /api/dashboard/summary
const getSummary = async (req, res, next) => {
  try {
    const matchOwner =
      req.user.role === 'sales_rep' ? { owner: req.user._id } : {};

    const [byStage, totals, monthly] = await Promise.all([
      Lead.aggregate([
        { $match: matchOwner },
        { $group: { _id: '$stage', count: { $sum: 1 }, value: { $sum: '$value' } } },
      ]),
      Lead.aggregate([
        { $match: matchOwner },
        {
          $group: {
            _id: null,
            totalLeads: { $sum: 1 },
            totalValue: { $sum: '$value' },
            wonValue: {
              $sum: { $cond: [{ $eq: ['$stage', 'Won'] }, '$value', 0] },
            },
            wonCount: {
              $sum: { $cond: [{ $eq: ['$stage', 'Won'] }, 1, 0] },
            },
            lostCount: {
              $sum: { $cond: [{ $eq: ['$stage', 'Lost'] }, 1, 0] },
            },
          },
        },
      ]),
      Lead.aggregate([
        { $match: { ...matchOwner, stage: 'Won', closedAt: { $ne: null } } },
        {
          $group: {
            _id: { year: { $year: '$closedAt' }, month: { $month: '$closedAt' } },
            value: { $sum: '$value' },
            count: { $sum: 1 },
          },
        },
        { $sort: { '_id.year': 1, '_id.month': 1 } },
      ]),
    ]);

    res.json({
      byStage,
      totals: totals[0] || { totalLeads: 0, totalValue: 0, wonValue: 0, wonCount: 0, lostCount: 0 },
      monthlyWonRevenue: monthly,
    });
  } catch (err) {
    next(err);
  }
};

// GET /api/dashboard/leaderboard  (sales reps ranked by won value)
const getLeaderboard = async (req, res, next) => {
  try {
    const leaderboard = await Lead.aggregate([
      { $match: { stage: 'Won' } },
      {
        $group: {
          _id: '$owner',
          wonValue: { $sum: '$value' },
          wonCount: { $sum: 1 },
        },
      },
      { $sort: { wonValue: -1 } },
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'user',
        },
      },
      { $unwind: '$user' },
      {
        $project: {
          name: '$user.name',
          email: '$user.email',
          wonValue: 1,
          wonCount: 1,
        },
      },
    ]);
    res.json(leaderboard);
  } catch (err) {
    next(err);
  }
};

module.exports = { getSummary, getLeaderboard };
