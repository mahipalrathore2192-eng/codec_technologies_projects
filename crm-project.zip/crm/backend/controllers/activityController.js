const Activity = require('../models/Activity');

// GET /api/activities?lead=&customer=
const getActivities = async (req, res, next) => {
  try {
    const { lead, customer } = req.query;
    const filter = {};
    if (lead) filter.lead = lead;
    if (customer) filter.customer = customer;

    const activities = await Activity.find(filter)
      .populate('user', 'name email')
      .populate('lead', 'title')
      .populate('customer', 'name')
      .sort({ createdAt: -1 });

    res.json(activities);
  } catch (err) {
    next(err);
  }
};

// POST /api/activities
const createActivity = async (req, res, next) => {
  try {
    const activity = await Activity.create({ ...req.body, user: req.user._id });
    res.status(201).json(activity);
  } catch (err) {
    next(err);
  }
};

module.exports = { getActivities, createActivity };
