const Lead = require('../models/Lead');
const Activity = require('../models/Activity');

// GET /api/leads  (supports ?stage=&owner=&search=)
const getLeads = async (req, res, next) => {
  try {
    const { stage, owner, search } = req.query;
    const filter = {};

    if (stage) filter.stage = stage;
    if (owner) filter.owner = owner;
    if (search) filter.title = { $regex: search, $options: 'i' };

    // sales_rep can only see their own leads; managers/admins see all
    if (req.user.role === 'sales_rep') {
      filter.owner = req.user._id;
    }

    const leads = await Lead.find(filter)
      .populate('customer', 'name company')
      .populate('owner', 'name email')
      .sort({ updatedAt: -1 });

    res.json(leads);
  } catch (err) {
    next(err);
  }
};

// GET /api/leads/:id
const getLead = async (req, res, next) => {
  try {
    const lead = await Lead.findById(req.params.id)
      .populate('customer')
      .populate('owner', 'name email');
    if (!lead) return res.status(404).json({ message: 'Lead not found' });
    res.json(lead);
  } catch (err) {
    next(err);
  }
};

// POST /api/leads
const createLead = async (req, res, next) => {
  try {
    const lead = await Lead.create({ ...req.body, owner: req.body.owner || req.user._id });
    await Activity.create({
      type: 'Note',
      subject: 'Lead created',
      description: `Lead "${lead.title}" created`,
      lead: lead._id,
      user: req.user._id,
    });
    res.status(201).json(lead);
  } catch (err) {
    next(err);
  }
};

// PUT /api/leads/:id
const updateLead = async (req, res, next) => {
  try {
    const lead = await Lead.findById(req.params.id);
    if (!lead) return res.status(404).json({ message: 'Lead not found' });

    const previousStage = lead.stage;
    Object.assign(lead, req.body);

    if (req.body.stage && req.body.stage !== previousStage) {
      if (['Won', 'Lost'].includes(req.body.stage)) {
        lead.closedAt = new Date();
      }
      await Activity.create({
        type: 'StageChange',
        subject: `Stage changed: ${previousStage} -> ${req.body.stage}`,
        lead: lead._id,
        user: req.user._id,
      });
    }

    await lead.save();
    res.json(lead);
  } catch (err) {
    next(err);
  }
};

// DELETE /api/leads/:id
const deleteLead = async (req, res, next) => {
  try {
    const lead = await Lead.findById(req.params.id);
    if (!lead) return res.status(404).json({ message: 'Lead not found' });
    await lead.deleteOne();
    res.json({ message: 'Lead deleted' });
  } catch (err) {
    next(err);
  }
};

// GET /api/leads/stages/list
const getStages = (req, res) => {
  res.json(Lead.DEAL_STAGES);
};

module.exports = { getLeads, getLead, createLead, updateLead, deleteLead, getStages };
