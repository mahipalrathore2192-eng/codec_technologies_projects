const User = require('../models/User');

// GET /api/users  (admin/sales_manager only)
const getUsers = async (req, res, next) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    next(err);
  }
};

// PUT /api/users/:id/role  (admin only)
const updateUserRole = async (req, res, next) => {
  try {
    const { role, isActive } = req.body;
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (role) user.role = role;
    if (typeof isActive === 'boolean') user.isActive = isActive;

    await user.save();
    res.json(user.toSafeObject());
  } catch (err) {
    next(err);
  }
};

module.exports = { getUsers, updateUserRole };
