require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./db');
const User = require('../models/User');
const Customer = require('../models/Customer');
const Lead = require('../models/Lead');
const Activity = require('../models/Activity');

const seed = async () => {
  await connectDB();

  await Promise.all([
    User.deleteMany(),
    Customer.deleteMany(),
    Lead.deleteMany(),
    Activity.deleteMany(),
  ]);

  const admin = await User.create({
    name: 'Admin User',
    email: 'admin@crm.com',
    password: 'admin123',
    role: 'admin',
  });

  const manager = await User.create({
    name: 'Sam Manager',
    email: 'manager@crm.com',
    password: 'manager123',
    role: 'sales_manager',
  });

  const rep = await User.create({
    name: 'Riya Rep',
    email: 'rep@crm.com',
    password: 'rep12345',
    role: 'sales_rep',
  });

  const customer1 = await Customer.create({
    name: 'Acme Corp',
    company: 'Acme Corp',
    email: 'contact@acme.com',
    industry: 'Manufacturing',
    owner: rep._id,
  });

  const customer2 = await Customer.create({
    name: 'Globex Inc',
    company: 'Globex Inc',
    email: 'info@globex.com',
    industry: 'Technology',
    owner: manager._id,
  });

  const lead1 = await Lead.create({
    title: 'Acme - Annual License Renewal',
    customer: customer1._id,
    contactName: 'John Acme',
    contactEmail: 'john@acme.com',
    source: 'Referral',
    stage: 'Proposal Sent',
    value: 25000,
    probability: 60,
    owner: rep._id,
    priority: 'High',
  });

  const lead2 = await Lead.create({
    title: 'Globex - New Implementation',
    customer: customer2._id,
    contactName: 'Jane Globex',
    contactEmail: 'jane@globex.com',
    source: 'Website',
    stage: 'Won',
    value: 50000,
    probability: 100,
    owner: manager._id,
    priority: 'High',
    closedAt: new Date(),
  });

  await Activity.create([
    {
      type: 'Email',
      subject: 'Sent renewal proposal',
      lead: lead1._id,
      customer: customer1._id,
      user: rep._id,
    },
    {
      type: 'Call',
      subject: 'Kickoff call with Globex',
      lead: lead2._id,
      customer: customer2._id,
      user: manager._id,
    },
  ]);

  console.log('Seed data created successfully:');
  console.log('  admin@crm.com / admin123');
  console.log('  manager@crm.com / manager123');
  console.log('  rep@crm.com / rep12345');

  await mongoose.connection.close();
  process.exit(0);
};

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
