const express = require('express');
const {
  getLeads,
  getLead,
  createLead,
  updateLead,
  deleteLead,
  getStages,
} = require('../controllers/leadController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.get('/stages/list', getStages);
router.route('/').get(getLeads).post(createLead);
router
  .route('/:id')
  .get(getLead)
  .put(updateLead)
  .delete(authorize('admin', 'sales_manager'), deleteLead);

module.exports = router;
