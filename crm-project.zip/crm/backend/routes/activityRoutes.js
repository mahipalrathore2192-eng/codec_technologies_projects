const express = require('express');
const { getActivities, createActivity } = require('../controllers/activityController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.route('/').get(getActivities).post(createActivity);

module.exports = router;
