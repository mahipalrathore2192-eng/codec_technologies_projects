const express = require('express');
const { getUsers, updateUserRole } = require('../controllers/userController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.get('/', authorize('admin', 'sales_manager'), getUsers);
router.put('/:id/role', authorize('admin'), updateUserRole);

module.exports = router;
