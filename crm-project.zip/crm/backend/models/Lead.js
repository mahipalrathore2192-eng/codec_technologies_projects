const mongoose = require('mongoose');

const DEAL_STAGES = [
  'New',
  'Contacted',
  'Qualified',
  'Proposal Sent',
  'Negotiation',
  'Won',
  'Lost',
];

const leadSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
    contactName: { type: String, trim: true },
    contactEmail: { type: String, trim: true },
    source: {
      type: String,
      enum: ['Website', 'Referral', 'Cold Call', 'Social Media', 'Event', 'Other'],
      default: 'Other',
    },
    stage: {
      type: String,
      enum: DEAL_STAGES,
      default: 'New',
    },
    value: { type: Number, default: 0 },
    probability: { type: Number, default: 10, min: 0, max: 100 },
    expectedCloseDate: { type: Date },
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    priority: { type: String, enum: ['Low', 'Medium', 'High'], default: 'Medium' },
    closedAt: { type: Date },
  },
  { timestamps: true }
);

leadSchema.statics.DEAL_STAGES = DEAL_STAGES;

module.exports = mongoose.model('Lead', leadSchema);
